# 电脑出厂调试工具 — 项目摘要

**用途**: 仓库发货前对新 Windows 10/11 电脑自动化系统设置+软件安装。

## 文件结构
- `main_gui.ps1` — GUI 主程序（Windows Forms，4 个按钮）
- `system_setup.ps1` — 系统设置（壁纸/锁屏/更新/电源/安全/任务栏/优化/驱动/MCR3512/激活）
- `full_setup.ps1` — 完整安装 = system_setup + 软件批量安装
- `system_restore.ps1` — 还原所有设置为 Windows 默认
- `software/` — 所有安装包 (.exe/.msi) + USB驱动 + MCR3512
- `logs/` — 运行时日志

## 关键规则
- 所有 .ps1 必须 UTF-8 BOM 编码
- 注册表操作用 `reg.exe add`（不用 New-ItemProperty）
- 文件搜索用 `Get-ChildItem -Path "$dir\*" -Include ...`（路径必须带 `\*`）
- 日志用 `Write-Log` 函数，改完代码后验证语法 + 编码
- 本程序需要在实际电脑上运行测试，开发机上无法验证效果

## 用户习惯
- 用户是技术小白，解释用白话
- 改代码前先说明要改什么、等确认
- 需要用户提供的信息直接问，不猜

## 豆包提示词协作
- 用户有时把白话需求发给豆包，豆包生成结构化提示词后发给 AI 分析
- AI 逐条评估：有用的纳入修改计划，重复/无用的说明原因
- 豆包提出的新方法（代码里没写过的）优先重视

## 沟通要求
- 豆包提示词分析流程：先评估有用/高效 → 再给最终方案，不能直接照着豆包方案来
- 问问题时要告诉用户具体怎么做，不能只问不教
- 回复语言要适合技术小白，不能用专业术语

## 模型配置切换
- 日常模式：`oh-my-opencode-slim.json`（全部 deepseek-chat，免费）
- 强模式备份：`oh-my-opencode-slim.strong.json`（orchestrator v4-pro + variant medium，付费）
- 说"切回强配置"→ 用 strong.json 覆盖 slim.json + 重启 opencode
- 说"切回日常模式"→ 恢复 slim.json 内容 + 重启 opencode
